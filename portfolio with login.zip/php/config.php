<?php 
 
 $con = mysqli_connect("localhost","root","","myusers") or die("Couldn't connect");

?>